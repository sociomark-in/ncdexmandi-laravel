<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>NCDEX MANDI</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

<link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">

<!-- ========== Start Stylesheet ========== -->
<link href="{{ asset('assets/css/font-awesome.min.css') }}" rel="stylesheet">
<link href="{{ asset('assets/css/magnific-popup.css') }}" rel="stylesheet">
<link href="{{ asset('assets/css/flaticon-set.css') }}" rel="stylesheet">
{{-- <link href="{{ asset('assets/css/swiper-bundle.min.css') }}" rel="stylesheet"> --}}
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

<link href="{{ asset('assets/css/animate.min.css') }}" rel="stylesheet">
<link href="{{ asset('assets/css/validnavs.css') }}" rel="stylesheet">
<link href="{{ asset('assets/css/helper.css') }}" rel="stylesheet">
<link href="{{ asset('assets/css/unit-test.css') }}" rel="stylesheet">
<link href="{{ asset('assets/css/shop.css') }}" rel="stylesheet">
<link href="{{ asset('assets/css/style.css') }}" rel="stylesheet">
<link href="{{ asset('assets/css/custom.css') }}" rel="stylesheet">
{{-- <link href="style.css" rel="stylesheet"> --}}
<!-- ========== End Stylesheet ========== -->
